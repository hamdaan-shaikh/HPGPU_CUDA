#!/bin/bash

git clone https://github.com/NVlabs/cub.git ext/
